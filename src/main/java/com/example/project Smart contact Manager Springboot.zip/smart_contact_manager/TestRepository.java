package com.example.smart_contact_manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class TestRepository {

	// Sign Up 
	public Map save(User user) {
		String name = user.getName();
		String emailid = user.getEmailid();
		String password = user.getPassword();
		String mobilenumber = user.getMobilenumber();
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smart_contact_manager","root","1234");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query = "select * from registration where emailId = '"+emailid+"'";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(query);
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		HashMap map = new HashMap<>();
		try {
			if(rs.next()) {
				map.put("message","you are already signed up do login");
				return map;
			}
			else {
				String query1 = "insert into registration values(?,?,?,?)";
				PreparedStatement pstmt1 = con.prepareStatement(query1);
				pstmt1.setString(1, name);
				pstmt1.setString(2, emailid);
				pstmt1.setString(3, password);
				pstmt1.setString(4, mobilenumber);
				int i = pstmt1.executeUpdate();
					if(i>=1) {
						map.put("Message", "You are signed-up sucessfully");
						return map;
					}
					else {
						map.put("Messege", "Something went wrong try again later");
						return map;
					}
					}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Log in
	public Map login(User user) {
		String emailid = user.getEmailid();
		String password = user.getPassword();
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smart_contact_manager","root","1234");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		String query = "Select password from registration where emailid='"+emailid+"'";
		PreparedStatement pstmt = null;
		try {
			pstmt = con.prepareStatement(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = pstmt.executeQuery();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		HashMap map = new HashMap();
		try {
			if(rs.next()) {
				try {
					if(rs.getString("password").equals(password))
					{
						map.put("Message","Password Correct login successfully");
						return map;
					}
					else {
						map.put("Message", "Password Wrong");
						return map;
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			else {
				map.put("Message", "You are not registered Yet do register before login");
				return map;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	// Forget Password
	public Map forgetPassword(User user) throws ClassNotFoundException, SQLException {
		String emailid = user.getEmailid();
		String password = user.getPassword();
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smart_contact_manager","root","1234");
		Statement stmt = con.createStatement();
		String query = "Select password from registration where emailid='"+emailid+"'";
		ResultSet rs = stmt.executeQuery(query);
		HashMap map = new HashMap();
		if(rs.next()) {
			if(rs.getString("password").equals(password)) {
				map.put("message","your password is correct something went wrong");
				return map;
			}
			else {
				String query1 = "update registration set password=? where emailid='"+emailid+"'";
				PreparedStatement pstmt = con.prepareStatement(query1);
				pstmt.setString(1, password);
				int i = pstmt.executeUpdate();
				if(i>=1) {
					map.put("message","your password updated successfully do login");
					return map;
				}
				else {
					map.put("Ooop", "Something went wrong try again later");
					return map;
				}
			}
		}
		return null;
	}
	
}



