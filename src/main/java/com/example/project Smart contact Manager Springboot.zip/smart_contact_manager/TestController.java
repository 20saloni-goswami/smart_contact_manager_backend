package com.example.smart_contact_manager;

import java.sql.SQLException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

//@CrossOrigin(origins = "http://localhost:3000/")
@RestController
public class TestController {
	
//	@PostMapping("/signup")
//	public Map home(HttpServletRequest req) throws ClassNotFoundException, SQLException{
//		String name = req.getParameter("name");
//		String emailid = req.getParameter("emailid");
//		String password = req.getParameter("password");
//		String mobilenumber = req.getParameter("mobilenumber");
//		Class.forName("com.mysql.jdbc.Driver");
//		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smart_contact_manager","root","1234");
//		String query = "select * from registration where emailId = '"+emailid+"'";
//		PreparedStatement pstmt = con.prepareStatement(query);
//		ResultSet rs = pstmt.executeQuery();
//		HashMap map = new HashMap<>();
//		if(rs.next()) {
//			map.put("Messege", "You are already signed-up");
//			return map;
//		}
//		else {
//			String query1 = "insert into registration values(?,?,?,?)";
//			PreparedStatement pstmt1 = con.prepareStatement(query1);
//			pstmt1.setString(1, name);
//			pstmt1.setString(2, emailid);
//			pstmt1.setString(3, password);
//			pstmt1.setString(4, mobilenumber);
//			int i = pstmt1.executeUpdate();
//				if(i>=1) {
//					map.put("Message", "You are signed-up sucessfully");
//					return map;
//				}
//				else {
//					map.put("Messege", "Something went wrong try again later");
//					return map;
//				}
//				}
//	}
	
	@Autowired 
	TestService testService;
//	private UserDAO uDAO;
	@PostMapping("/signup")
	public Map signup(User user) {
		return testService.save(user);
	}
	
	@PostMapping("/login")
	public Map login(User user) {
		return testService.login(user);
	}
	 
	@PostMapping("/forgetpasword")
	public Map forgetPassword(User user) throws ClassNotFoundException, SQLException {
		return testService.forgetPassword(user);
	}
	}

