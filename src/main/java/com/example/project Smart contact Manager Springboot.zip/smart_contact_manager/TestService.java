package com.example.smart_contact_manager;

import java.sql.SQLException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestService {
	@Autowired
	TestRepository testRepository;

	public Map save(User user) {
		Map map = testRepository.save(user);
		return map;
	}

	public Map login(User user) {
		Map map = testRepository.login(user);
		return map;
	}

	public Map forgetPassword(User user) throws ClassNotFoundException, SQLException {
		Map map = testRepository.forgetPassword(user);
		return map;
	}
}
